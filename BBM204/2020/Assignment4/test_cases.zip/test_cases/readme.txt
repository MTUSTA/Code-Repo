list of the words you must remove from every url

https
http
www

package tst;

import java.util.ArrayList;
import java.util.List;

public class TST<Value> {
    private Node<Value> root;

    private static class Node<Value> {
        private char c;
        private Node<Value> left, mid, right;
        private Value val;
    }

    // Inserts the key value pair into ternary search tree
    public void put(String key, Value val) {
        /* Code here */
    }

    // Returns a list of values using the given prefix
    public List<Value> valuesWithPrefix(String prefix) {
        /* Code here */
        return new ArrayList<>();
    }
}
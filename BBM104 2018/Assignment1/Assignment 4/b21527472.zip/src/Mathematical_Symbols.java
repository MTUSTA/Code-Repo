
public class Mathematical_Symbols extends Gem{

	public Mathematical_Symbols(String gemtype, int coordx, int coordy) {
		super(gemtype, 20, coordx, coordy);
		// TODO Auto-generated constructor stub
	}


}

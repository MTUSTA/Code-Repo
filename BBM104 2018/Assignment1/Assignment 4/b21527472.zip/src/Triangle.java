
public class Triangle extends Gem{
	public Triangle(int x,int y) {
		super("T",15,x,y);
		// TODO Auto-generated constructor stub
	}

}

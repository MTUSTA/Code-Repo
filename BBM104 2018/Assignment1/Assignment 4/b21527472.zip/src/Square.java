
public class Square extends Gem{
	public Square(int x,int y) {
		super("S",15,x,y);
	}

}


public class Wildcard extends Gem{
	public Wildcard(int x,int y) {
		super("W",10,x,y);
	}

}

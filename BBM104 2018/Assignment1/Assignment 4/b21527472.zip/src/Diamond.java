
public class Diamond extends Gem{
	public Diamond(int x,int y) {
		super("D",30,x,y);
	}

}

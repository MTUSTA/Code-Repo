
public class EmptyGem extends Gem{

	public EmptyGem(int coordx, int coordy) {
		super(" ", 0, coordx, coordy);
	}

}

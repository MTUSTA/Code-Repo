firstly wordVec.text is read
each vector is calculated as cosine similarity to the other vectors.Then added to the arraylist by turning it into an edge object

the desired wordpair is read.

the words read will be removed from the array .ex = cat will be "cat"

then create the EdgeWeightedGraph object

pair arraylist takes words in order

the appropriate EDGEs are added to EdgeWeightedGraph

then the farthest distances are found as much as the desired number of clustering.

Then the farthest defined distances are torn off.
the remaining groups print out in output.txt
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;

public class Main {
	public static void main(String[] args) throws IOException {
		// store Contact object
		ArrayList<Contact> contacts = new ArrayList<Contact>();
		// reader object
		Reader rd = new Reader();
		// input lines
		String[] lines = rd.readfile(args[0]);
		// create object and adding
		for (String s : lines) {
			String[] split_s = s.split(" ");
			// new Contact(phoneNumber[0], firstName, lastName, socialSecurityNumber)
			contacts.add(new Contact(split_s[0], split_s[1], split_s[2], split_s[3]));
		}
		
		
		// Article 1
		FileWriter writer = new FileWriter(new File("contactsArrayList.txt"));
		// arraylist iterator
		Iterator<Contact> iter1 = contacts.iterator();
		while (iter1.hasNext()) {
			Contact temp = iter1.next();
			writer.write(temp.getPhoneNumber() + " " + temp.getFirstName() + " " + temp.getLastName() + " "
					+ temp.getSocialSecurityNumber() + "\n");
		}
		writer.flush();
		
		
		// Article 2
		writer = new FileWriter(new File("contactsArrayListOrderByLastName.txt"));
		// sorting arraylist with LastNameComparator Object
		ArrayList<Contact> copy = new ArrayList<Contact>(contacts);
		Collections.sort(copy, new LastNameComparator());
		for (Contact c : copy) {
			writer.write(c.getPhoneNumber() + " " + c.getFirstName() + " " + c.getLastName() + " "
					+ c.getSocialSecurityNumber() + "\n");
		}
		writer.flush();
		
		
		// Article 3
		writer = new FileWriter(new File("contactsHashSet.txt"));
		HashSet<Contact> h = new HashSet<Contact>();
		// adding Contact element in h -> hashset
		for (Contact c : contacts) {
			h.add(c);
		}
		// hashset iterator
		Iterator<Contact> iter2 = h.iterator();
		while (iter2.hasNext()) {
			Contact temp = iter2.next();
			writer.write(temp.getPhoneNumber() + " " + temp.getFirstName() + " " + temp.getLastName() + " "
					+ temp.getSocialSecurityNumber() + "\n");
		}
		writer.flush();

		
		// Article 4
		TreeSet<Contact> ts1 = new TreeSet<Contact>();
		//adding Contact element in ts1 -> TreeSet
		for (Contact c : contacts) {
			ts1.add(c);
		}
		// TreeSet iterator
		Iterator<Contact> iter3 = ts1.iterator();
		writer = new FileWriter(new File("contactsTreeSet.txt"));
		while (iter3.hasNext()) {
			Contact temp = iter3.next();
			writer.write(temp.getPhoneNumber() + " " + temp.getFirstName() + " " + temp.getLastName() + " "
					+ temp.getSocialSecurityNumber() + "\n");
		}
		writer.flush();
		
		
		// Article 5
		// sorting TreeSet with LastNameComparator object
		TreeSet<Contact> ts2 = new TreeSet<Contact>(new LastNameComparator());
		for (Contact c : contacts) {
			ts2.add(c);
		}
		writer = new FileWriter(new File("contactsTreeSetOrderByLastName.txt"));
		for (Contact c : ts2) {
			writer.write(c.getPhoneNumber() + " " + c.getFirstName() + " " + c.getLastName() + " "
					+ c.getSocialSecurityNumber() + "\n");
		}
		writer.flush();
		
		
		// Article 6
		HashMap<String, Contact> hashmap = new HashMap<String, Contact>();
		// Adding Object in hashmap
		for (Contact c : contacts) {
			hashmap.put(c.getPhoneNumber(), c);
		}
		writer = new FileWriter(new File("contactsHashMap.txt"));
		// Hashmap iterator
		Iterator<Map.Entry<String, Contact>> entries = hashmap.entrySet().iterator();

		while (entries.hasNext()) {
			Map.Entry<String, Contact> c = entries.next();
			writer.write(c.getValue().getPhoneNumber() + " " + c.getValue().getFirstName() + " "
					+ c.getValue().getLastName() + " " + c.getValue().getSocialSecurityNumber() + "\n");
		}
		writer.flush();

		writer.close();
	}

}

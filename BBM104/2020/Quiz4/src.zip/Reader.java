import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class Reader {

	public String[] readfile(String path) {
		try {
			int i = 0;
			int len = Files.readAllLines(Paths.get(path)).size();
			String[] results = new String[len];
			for (String line : Files.readAllLines(Paths.get(path))) {
				// delete newline character
				line = line.replace("\n", "").replace("\r", "");
				results[i++] = line;
			}
			return results;

		} catch (Exception e) {
			e.printStackTrace();
			return null;	
		}
	}
}

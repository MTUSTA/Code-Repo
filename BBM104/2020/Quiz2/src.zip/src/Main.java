import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		Reader rd = new Reader();
		ArrayList<Sports> fikstur = rd.readfile(args[0]);
		Printer pt = new Printer();
		pt.printFile(fikstur);
	}
}
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class Printer {

	public void printFile(ArrayList<Sports> fikstur) {
		try {
			ArrayList<VolleyBall> volleyball = new ArrayList<VolleyBall>();
			ArrayList<BasketBall> basketball = new ArrayList<BasketBall>();
			ArrayList<IceHockey> icehockey = new ArrayList<IceHockey>();
			ArrayList<HandBall> handball = new ArrayList<HandBall>();

			for (Sports element : fikstur) {
				if (element.getClass() == VolleyBall.class) {
					volleyball.add((VolleyBall) element);
				}
				if (element.getClass() == BasketBall.class) {
					basketball.add((BasketBall) element);
				}
				if (element.getClass() == IceHockey.class) {
					icehockey.add((IceHockey) element);
				}
				if (element.getClass() == HandBall.class) {
					handball.add((HandBall) element);
				}
			}
			// sorting arraylist
			Collections.sort(volleyball,  (player1, player2) -> player2.point - player1.point);
			Collections.sort(basketball,  (player1, player2) -> player2.point - player1.point);
			Collections.sort(icehockey,  (player1, player2) -> player2.point - player1.point);
			Collections.sort(handball,  (player1, player2) -> player2.point - player1.point);
			
			FileWriter Volleyball = new FileWriter("Volleyball.txt");
			for (int i = 0; i < volleyball.size(); i++) {
				Volleyball.write((i + 1) + ".\t" + volleyball.get(i).club_name + "\t" + volleyball.get(i).played_matches
						+ "\t" + volleyball.get(i).matches_won + "\t" + volleyball.get(i).matches_even_score + "\t"
						+ volleyball.get(i).matches_loss + "\t" + volleyball.get(i).total_status[0] + ":"
						+ volleyball.get(i).total_status[1] + "\t" + volleyball.get(i).point + "\n");

			}
			FileWriter Basketball = new FileWriter("Basketball.txt");
			for (int i = 0; i < basketball.size(); i++) {
				Basketball.write((i + 1) + ".\t" + basketball.get(i).club_name + "\t" + basketball.get(i).played_matches
						+ "\t" + basketball.get(i).matches_won + "\t" + basketball.get(i).matches_even_score + "\t"
						+ basketball.get(i).matches_loss + "\t" + basketball.get(i).total_status[0] + ":"
						+ basketball.get(i).total_status[1] + "\t" + basketball.get(i).point + "\n");

			}
			FileWriter Icehockey = new FileWriter("IceHockey.txt");
			for (int i = 0; i < icehockey.size(); i++) {
				Icehockey.write((i + 1) + ".\t" + icehockey.get(i).club_name + "\t" + icehockey.get(i).played_matches
						+ "\t" + icehockey.get(i).matches_won + "\t" + icehockey.get(i).matches_even_score + "\t"
						+ icehockey.get(i).matches_loss + "\t" + icehockey.get(i).total_status[0] + ":"
						+ icehockey.get(i).total_status[1] + "\t" + icehockey.get(i).point + "\n");

			}

			FileWriter Handball = new FileWriter("Handball.txt");
			for (int i = 0; i < handball.size(); i++) {
				Handball.write((i + 1) + ".\t" + handball.get(i).club_name + "\t" + handball.get(i).played_matches
						+ "\t" + handball.get(i).matches_won + "\t" + handball.get(i).matches_even_score + "\t"
						+ handball.get(i).matches_loss + "\t" + handball.get(i).total_status[0] + ":"
						+ handball.get(i).total_status[1] + "\t" + handball.get(i).point + "\n");

			}

			Icehockey.close();
			Handball.close();
			Basketball.close();
			Volleyball.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}


public class HandBall extends Sports{

	public HandBall(String club_name) {
		super(club_name);
		// TODO Auto-generated constructor stub
	}



}

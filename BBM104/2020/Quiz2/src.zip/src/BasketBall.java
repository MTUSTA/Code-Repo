
public class BasketBall extends Sports{

	public BasketBall(String club_name) {
		super(club_name);
		// TODO Auto-generated constructor stub
	}


}

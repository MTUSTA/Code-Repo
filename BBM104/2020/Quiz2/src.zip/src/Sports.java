
public class Sports{
	public String club_name;
	public int played_matches = 0;
	public int matches_won = 0;
	public int matches_even_score = 0;
	public int matches_loss = 0;
	public int[] total_status = {0,0};
	public int point = 0;
	public Sports(String club_name) {
		this.club_name = club_name;
	}

}

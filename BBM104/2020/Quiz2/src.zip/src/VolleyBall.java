
public class VolleyBall extends Sports{

	public VolleyBall(String club_name) {
		super(club_name);
		// TODO Auto-generated constructor stub
	}

}

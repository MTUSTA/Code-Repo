
public class IceHockey extends Sports{

	public IceHockey(String club_name) {
		super(club_name);
		// TODO Auto-generated constructor stub
	}



}

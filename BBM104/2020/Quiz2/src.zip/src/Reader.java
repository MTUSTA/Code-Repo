import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Reader {
	public ArrayList<Sports> readfile(String Argument) {

		ArrayList<Sports> objects = new ArrayList<Sports>();

		try { 
			
			//Scanner object is created & take argument
			Scanner scan = new Scanner(new File(Argument));
			// Checking line
			while (scan.hasNextLine()) {
				String line = scan.nextLine(); // read line
				String[] split_line = line.split("\t"); // split line
				process(objects,split_line);
			}

			scan.close();
			return objects;

		} catch (FileNotFoundException ex) {
			System.out.println("No File Found!");
			return null;

		}
	}

	public void process(ArrayList<Sports> objects, String[] split_line) {
		int first = finder(objects, split_line[0], split_line[1]);
		int second = finder(objects, split_line[0], split_line[2]);
		
		if(first == -1) {
			Sports objt1 = null;
			if(split_line[0].compareTo("I")==0) {
				objt1 = new IceHockey(split_line[1]);
			}
			else if(split_line[0].compareTo("H")==0) {
				objt1 = new HandBall(split_line[1]);
			}
			else if(split_line[0].compareTo("V")==0) {
				objt1 = new VolleyBall(split_line[1]);
			}
			else if(split_line[0].compareTo("B")==0) {
				objt1 = new BasketBall(split_line[1]);
			}
			objects.add(objt1);
			first= objects.size()-1;
		}
		if(second == -1) {
			Sports objt2 = null;
			if(split_line[0].compareTo("I")==0) {
				//System.out.println("I");
				objt2 = new IceHockey(split_line[2]);
			}
			else if(split_line[0].compareTo("H")==0) {
				//System.out.println("H");
				objt2 = new HandBall(split_line[2]);
			}
			else if(split_line[0].compareTo("V")==0) {
				//System.out.println("V");
				objt2 = new VolleyBall(split_line[2]);
			}
			else if(split_line[0].compareTo("B")==0) {
				//System.out.println("B");
				objt2 = new BasketBall(split_line[2]);
			}
			objects.add(objt2);
			second = objects.size()-1;
		}
		
		if(split_line[0].compareTo("I")==0) {
			String[] skor = split_line[3].split(":");
			int skor1 = Integer.parseInt(skor[0]);
			int skor2 = Integer.parseInt(skor[1]);
			if(skor1 > skor2) {
				// winner
				objects.get(first).played_matches++;
				objects.get(first).matches_won++;
				objects.get(first).total_status[0] += skor1;
				objects.get(first).total_status[1] += skor2;
				objects.get(first).point +=3;
				// loser
				objects.get(second).played_matches++;
				objects.get(second).matches_loss++;
				objects.get(second).total_status[0] += skor2;
				objects.get(second).total_status[1] += skor1;
			}
			else if(skor1 < skor2) {
				// winner
				objects.get(second).played_matches++;
				objects.get(second).matches_won++;
				objects.get(second).total_status[0] += skor1;
				objects.get(second).total_status[1] += skor2;
				objects.get(second).point +=3;
				// loser
				objects.get(first).played_matches++;
				objects.get(first).matches_loss++;
				objects.get(first).total_status[0] += skor2;
				objects.get(first).total_status[1] += skor1;			
			}else {
				// round draw
				objects.get(second).played_matches++;
				objects.get(second).matches_even_score++;
				objects.get(second).total_status[0] += skor1;
				objects.get(second).total_status[1] += skor2;
				objects.get(second).point +=1;

				objects.get(first).played_matches++;
				objects.get(first).matches_even_score++;
				objects.get(first).total_status[0] += skor2;
				objects.get(first).total_status[1] += skor1;
				objects.get(first).point +=1;					
			}
		}
		if(split_line[0].compareTo("H")==0) {
			String[] skor = split_line[3].split(":");
			int skor1 = Integer.parseInt(skor[0]);
			int skor2 = Integer.parseInt(skor[1]);
			if(skor1 > skor2) {
				// winner
				objects.get(first).played_matches++;
				objects.get(first).matches_won++;
				objects.get(first).total_status[0] += skor1;
				objects.get(first).total_status[1] += skor2;
				objects.get(first).point +=2;
				// loser
				objects.get(second).played_matches++;
				objects.get(second).matches_loss++;
				objects.get(second).total_status[0] += skor2;
				objects.get(second).total_status[1] += skor1;
			}
			else if(skor1 < skor2) {
				// winner
				objects.get(second).played_matches++;
				objects.get(second).matches_won++;
				objects.get(second).total_status[0] += skor1;
				objects.get(second).total_status[1] += skor2;
				objects.get(second).point +=2;
				// loser
				objects.get(first).played_matches++;
				objects.get(first).matches_loss++;
				objects.get(first).total_status[0] += skor2;
				objects.get(first).total_status[1] += skor1;			
			}else {
				// round draw
				objects.get(second).played_matches++;
				objects.get(second).matches_even_score++;
				objects.get(second).total_status[0] += skor1;
				objects.get(second).total_status[1] += skor2;
				objects.get(second).point +=1;

				objects.get(first).played_matches++;
				objects.get(first).matches_even_score++;
				objects.get(first).total_status[0] += skor2;
				objects.get(first).total_status[1] += skor1;
				objects.get(first).point +=1;					
			}	
		}
		if(split_line[0].compareTo("V")==0) {
			String[] skor = split_line[3].split(":");
			int winner = Integer.parseInt(skor[0]);
			int loser = Integer.parseInt(skor[1]);
			//changing value
			if(loser > winner) {
				int temp = winner;
				winner = loser;
				loser = temp;
				
				// changing object index
				temp = second;
				second = first;
				first = temp;
			}
			
			if(winner == 3 && (loser == 0 || loser == 1)) {
				// winner
				objects.get(first).played_matches++;
				objects.get(first).matches_won++;
				objects.get(first).total_status[0] += winner;
				objects.get(first).total_status[1] += loser;
				objects.get(first).point +=3;
				// loser
				objects.get(second).played_matches++;
				objects.get(second).matches_loss++;
				objects.get(second).total_status[0] += loser;
				objects.get(second).total_status[1] += winner;				
			}
			if(winner == 3 && loser == 2) {
				// winner
				objects.get(first).played_matches++;
				objects.get(first).matches_won++;
				objects.get(first).total_status[0] += winner;
				objects.get(first).total_status[1] += loser;
				objects.get(first).point += 2;
				// loser
				objects.get(second).played_matches++;
				objects.get(second).matches_loss++;
				objects.get(second).total_status[0] += loser;
				objects.get(second).total_status[1] += winner;
				objects.get(second).point += 1;
			}
			
		}
		if(split_line[0].compareTo("B")==0) {
			String[] skor = split_line[3].split(":");
			int skor1 = Integer.parseInt(skor[0]);
			int skor2 = Integer.parseInt(skor[1]);
			if(skor1 > skor2) {
				// winner
				objects.get(first).played_matches++;
				objects.get(first).matches_won++;
				objects.get(first).total_status[0] += skor1;
				objects.get(first).total_status[1] += skor2;
				objects.get(first).point +=2;
				// loser
				objects.get(second).played_matches++;
				objects.get(second).matches_loss++;
				objects.get(second).total_status[0] += skor2;
				objects.get(second).total_status[1] += skor1;
				objects.get(second).point +=1;
			}
			else if(skor1 < skor2) {
				// winner
				objects.get(second).played_matches++;
				objects.get(second).matches_won++;
				objects.get(second).total_status[0] += skor1;
				objects.get(second).total_status[1] += skor2;
				objects.get(second).point +=2;
				// loser
				objects.get(first).played_matches++;
				objects.get(first).matches_loss++;
				objects.get(first).total_status[0] += skor2;
				objects.get(first).total_status[1] += skor1;
				objects.get(first).point +=1;
			}				
		}

		
	}
	// helper function to find object in arraylist
	public int finder(ArrayList<Sports> objects,String letter, String name) {
		for (int i = 0; i < objects.size(); i++) {
			// finding name
			if(objects.get(i).club_name.compareTo(name) == 0) {
				// return id if available object
				if(objects.get(i).getClass() == BasketBall.class && letter.equals("B")) {
					return i;
				}
				if(objects.get(i).getClass() == HandBall.class && letter.equals("H")) {
					return i;
				}
				if(objects.get(i).getClass() == IceHockey.class && letter.equals("I")) {
					return i;
				}
				if(objects.get(i).getClass() == VolleyBall.class && letter.equals("V")) {
					return i;
				}
			}
		}
		// if object doesnt exits ,return -1
		return -1;
		
	}

}


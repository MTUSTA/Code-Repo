
public class new_jewel extends Gem{

	public new_jewel(String gemtype, int puan, int coordx, int coordy) {
		super(gemtype, puan, coordx, coordy);
	}
}

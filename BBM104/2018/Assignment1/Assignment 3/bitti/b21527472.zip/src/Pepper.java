
public class Pepper extends Material{
	Material malzeme=null;
	public Pepper(Material malzeme) {
		super(1);
		this.malzeme=malzeme;
	}
	public Pepper() {
		super(1);
	}
}

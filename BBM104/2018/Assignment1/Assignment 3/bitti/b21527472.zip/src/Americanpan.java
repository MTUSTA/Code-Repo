
public class Americanpan extends Pizza{

	public Americanpan() {
		super(5, "AmericanPan");
	}

}

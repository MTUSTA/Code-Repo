
public class Neapolitan extends Pizza{

	public Neapolitan() {
		super(10, "Neapolitan");
	}

}


public class softdrink {
	private int value =1;
	public softdrink() {
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
}
